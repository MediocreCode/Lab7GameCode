import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Driver extends Application{
/*
 * Ya boi R-Dog
 * Trevor Henry
 * 10/19
 */
	
	//WHat i tried messing with this by adding the graphic parts like extends app
	// and the launch args along with the stage set title and scene
	public static void main(String[] args) {
		launch (args);
	}

	public void start(Stage primaryStage) throws Exception {
		//myStage = primaryStage;
		BorderPane myBorder = new BorderPane();		
	CoinItem c1 = new CoinItem();
	
	Group root = new Group();
	
	Scene myScene = new Scene(root, 700, 700, Color.BURLYWOOD); //BURLYWOOD!!!!
	
	System.out.println(c1.genCoinX()+" "+c1.genCoinY());
	HomeScreenGraphic hsg = new HomeScreenGraphic();
	//String str = new String(hsg.getPlayerName()); WE GOT A BUG WOOOOOOO!
	//System.out.println(str);
	
	primaryStage.setTitle("PostCard");
	primaryStage.setScene(myScene);  //This is just a placeholder for myScene And will be changed later
	primaryStage.show();
}
}

